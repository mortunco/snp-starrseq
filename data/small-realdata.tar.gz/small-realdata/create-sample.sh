samtools view -b -M -L  x.bed /groups/lackgrp/projects/inv-mattfreedman-snpstarrseq/analysis/process-asymmetric/rawmapping.pooled.bam | samtools sort -n -@5 -m10G - | samtools fastq -@ 5 - -s single.longshort.fastq -1 sample.longshort.r1.fastq -2 sample.longshort.r2.fastq
samtools view -b -M -L  x.bed /groups/lackgrp/projects/inv-mattfreedman-snpstarrseq/analysis/process-asymmetric/rawmapping.miseq3.bam | samtools sort -n -@5 -m10G - | samtools fastq -@ 5 - -s single.shortlong.fastq -1 sample.shortlong.r1.fastq -2 sample.shortlong.r2.fastq

samtools view -b -M -L x.bed /groups/lackgrp/projects/inv-mattfreedman-snpstarrseq/analysis/hiseq-data-analysis/SNP_CL.bam | samtools sort -n -@5 -m10G - | samtools fastq -@5 - -s sample.single.lib.fastq -1 sample.lib.r1.fastq -2 sample.lib.r2.fastq
samtools view -b -M -L x.bed /groups/lackgrp/projects/inv-mattfreedman-snpstarrseq/analysis/hiseq-data-analysis/SNPR1_48.bam | samtools sort -n -@5 -m10G - | samtools fastq -@5 - -s sample.single.481.fastq -1 sample.481.r1.fastq -2 sample.481.r2.fastq

